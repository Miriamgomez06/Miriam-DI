package model;

public interface Descargable {

    double velocidadInternet();
    double obtenerTamanoGB();
}
