package model;

public interface ElementoPlanificador {

    int getId();
    String getTitulo();
    public void mostrarDetalles();
}
